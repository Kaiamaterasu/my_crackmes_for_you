To the 0x0002 community.
I am stepping away for a while.
Everything you need to know is inside this file.
Good luck. -- 0x0002
